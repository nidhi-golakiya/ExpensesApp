from app.main import app  # Adjust this import based on your folder structure

application = app  # Elastic Beanstalk looks for this
